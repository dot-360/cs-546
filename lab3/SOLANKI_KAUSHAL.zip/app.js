const people=require('./people');
const stocks=require('./stocks')
async function main(){
  try{
        people.getPersonById('7989fa5e-8f3f-458d-ad58-23c8d9ef5a10');
    }
        catch(e){
            console.log(e);
        }
     try{
            people.sameStreet("sutherland", "point");
        }
            catch(e){
                console.log(e);
            }

       try{
             people.manipulateSsn()
         }   
         catch(e){
             console.log(" it will not work");
         }  
         try{
            people.sameBirthday(6,8) 
         }catch(e){
             console.log(e);
         }
   try{
        stocks.listShareholders()
    }   
    catch(e){
        console.log(" it will not work");
    }

    try{
        stocks.topShareholders('Aeglea BioTherapeutics, Inc.')
    }catch(e){

        console.log(e);}
    try{
            stocks.listStocks("Grenville", "Pawelke")
        }catch(e){
            console.log(e);
        }
    try{
        stocks.getStockById("f652f797-7ca0-4382-befb-2ab8be914ff0")
    }catch(e){

        console.log(e);}
    

 
}   
        main()